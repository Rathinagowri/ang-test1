describe("Check",function(){
	
it("check whether a value is defined or not", function() {
    var a = "10";
    expect(a).toBeDefined();

  });

it("check whether a value is null or not", function() {
    var b = null;
    expect(b).toBeNull();  
      });
})
